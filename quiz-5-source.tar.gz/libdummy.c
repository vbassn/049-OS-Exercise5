#include <stdio.h>


void dummyLibFunction()
{
    printf("Hello from the shared but dummy library!\n");

}
